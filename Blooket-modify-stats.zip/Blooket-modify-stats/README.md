﻿# Chrome Extension Template (Manifest V3)

## Quick start
1. Open Chrome and go to `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder.

## Structure
- `manifest.json`: extension configuration.
- `popup/`: popup UI (`popup.html`, `popup.css`, `popup.js`).
- `background/service-worker.js`: background event logic.
- `content/content.js`: content script injected into pages.
- `options/options.html`: starter options page.
- `icons/`: placeholder icons.

## What it does
- Popup button sends a message to the content script.
- Content script shows an alert on the active page.
- Background service worker includes a simple message handler.

Replace names, permissions, matches, and behavior with your real extension logic.
