﻿chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension template installed.");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "PING") {
    sendResponse({ ok: true, source: "service-worker" });
  }
});
