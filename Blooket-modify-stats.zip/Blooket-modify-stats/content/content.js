function getAccuracyColor(percent) {
  if (percent > 70) {
    return "rgb(34, 197, 94)";
  }

  if (percent >= 45) {
    return "rgb(245, 158, 11)";
  }

  return "rgb(196, 57, 53)";
}

function setFirstLeafBySelectors(selectors, newText) {
  for (const selector of selectors) {
    const nodes = Array.from(document.querySelectorAll(selector));

    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) {
        continue;
      }

      let target = null;

      if (node.children.length === 0) {
        target = node;
      } else {
        target = Array.from(node.querySelectorAll("*"))
          .filter((child) => child instanceof HTMLElement)
          .find((child) => child.children.length === 0 && /\d/.test(child.textContent || ""));
      }

      if (!target) {
        continue;
      }

      target.textContent = String(newText);
      return 1;
    }
  }

  return 0;
}

function applyVisualStatPrank(payload) {
  const percent = Number.isFinite(payload?.percent) ? payload.percent : 999;
  const correct = Number.isFinite(payload?.correct) ? payload.correct : 999;
  const total = Number.isFinite(payload?.total) ? Math.max(1, payload.total) : 1;
  const gold = Number.isFinite(payload?.gold) ? Math.max(0, payload.gold) : 999999;
  const place = Number.isFinite(payload?.place) ? Math.max(1, payload.place) : 1;

  const numbersText = `${correct} / ${total}`;
  const gradeText = `${percent}%`;
  const gradeColor = getAccuracyColor(percent);

  let accuracyChanged = 0;

  const container = document.querySelector("div._accuracyContainer_u5hlk_178");
  if (container) {
    const numbers = container.querySelector("div._accuracyNumbers_u5hlk_204");
    const grade = container.querySelector("div._accuracyGrade_u5hlk_212");

    if (numbers) {
      numbers.textContent = numbersText;
      accuracyChanged += 1;
    }

    if (grade) {
      grade.textContent = gradeText;
      grade.style.color = gradeColor;
      accuracyChanged += 1;
    }
  }

  if (accuracyChanged === 0) {
    const numbers = document.querySelector("[class*='accuracyNumbers']");
    const grade = document.querySelector("[class*='accuracyGrade']");

    if (numbers) {
      numbers.textContent = numbersText;
      accuracyChanged += 1;
    }

    if (grade) {
      grade.textContent = gradeText;
      grade.style.color = gradeColor;
      accuracyChanged += 1;
    }
  }

  const goldChanged = setFirstLeafBySelectors(
    [
      "[class*='goldValue']",
      "[class*='goldAmount']",
      "[class*='goldText']",
      "[class*='GoldValue']",
      "[class*='GoldAmount']",
      "[class*='GoldText']",
      "[data-testid*='gold']"
    ],
    gold
  );

  const placeChanged = setFirstLeafBySelectors(
    [
      "[class*='placeValue']",
      "[class*='placeText']",
      "[class*='rankValue']",
      "[class*='rankText']",
      "[class*='standing']",
      "[class*='PlaceValue']",
      "[class*='RankValue']",
      "[data-testid*='place']",
      "[data-testid*='rank']"
    ],
    `#${place}`
  );

  const ok = accuracyChanged > 0 || goldChanged > 0 || placeChanged > 0;

  return {
    ok,
    accuracyChanged,
    goldChanged,
    placeChanged,
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "BLOOKET_PRANK_APPLY") {
    return;
  }

  const result = applyVisualStatPrank(message.payload || {});
  sendResponse(result);
});
