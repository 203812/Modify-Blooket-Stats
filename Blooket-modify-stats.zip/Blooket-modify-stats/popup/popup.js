const statusEl = document.getElementById("status");
const applyBtn = document.getElementById("applyBtn");
const percentInput = document.getElementById("percentInput");
const correctInput = document.getElementById("correctInput");
const totalInput = document.getElementById("totalInput");
const goldInput = document.getElementById("goldInput");
const placeInput = document.getElementById("placeInput");

function sanitizeNumber(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

async function sendApplyMessage(tabId, payload) {
  return chrome.tabs.sendMessage(tabId, {
    type: "BLOOKET_PRANK_APPLY",
    payload,
  });
}

applyBtn.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab?.id) {
    statusEl.textContent = "No active tab found.";
    return;
  }

  const payload = {
    percent: sanitizeNumber(percentInput.value, 999),
    correct: sanitizeNumber(correctInput.value, 999),
    total: Math.max(1, sanitizeNumber(totalInput.value, 1)),
    gold: Math.max(0, sanitizeNumber(goldInput.value, 999999)),
    place: Math.max(1, sanitizeNumber(placeInput.value, 1)),
  };

  try {
    let response;

    try {
      response = await sendApplyMessage(tab.id, payload);
    } catch {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content/content.js"],
      });
      response = await sendApplyMessage(tab.id, payload);
    }

    if (response?.ok) {
      const parts = [];
      if (response.accuracyChanged) {
        parts.push("accuracy");
      }
      if (response.goldChanged) {
        parts.push("gold");
      }
      if (response.placeChanged) {
        parts.push("place");
      }

      statusEl.textContent = parts.length
        ? `Updated: ${parts.join(", ")}.`
        : "Visual values updated.";
      return;
    }

    statusEl.textContent = "Target elements not found on this page.";
  } catch {
    statusEl.textContent = "Cannot inject here. Open a normal https:// Blooket tab.";
  }
});
